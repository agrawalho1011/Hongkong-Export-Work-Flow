﻿namespace APACExportTrackX.ViewModels
{
    public class FileAddActivityLogModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string CountryId { get; set; }
        public string FileNumber { get; set; } = null!;
        public string? Container { get; set; }
        public string? ShippingAgent { get; set; }
        public DateTime? ETAPOD { get; set; }
        public int? LBL { get; set; }
        public int? TBL { get; set; }
        public int? TotalHBL { get; set; }
        public string? FileContact { get; set; }
        public string? ShippingLine { get; set; }
        public DateTime? ETA { get; set; }
        public DateTime? ATD { get; set; }
        public DateTime? ETD { get; set; }
        public string? SICutOff { get; set; }
        public string? StartDateTime { get; set; }
        public DateTime? EnterDate { get; set; } = DateTime.Now;
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

        public List<FileActivityLogItem>? FileActivities { get; set; }
    }
    public class FileActivityLogItem
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string ActivityId { get; set; }

        public string StatusId { get; set; }

        public string? Comment { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
