﻿

var searchValue = null;
let statusValue = null;
let startDateValue = null;
let endDateValue = null;
let hblComments = null;
$(document).ready(function () {
    getHBLData();
    var activityList = activityIdDataList[0];
    var activityId = activityList.id;
    var activity = activityList.nameOfActivity;
    $('#hiddenLabel').text(activity);
    $('#hiddenLabelId').val(activityId);
});


function getHBLData() {
    var ele = $(".container-fluid");
    console.log(window.screen.height);
    console.log(ele[0].getBoundingClientRect().bottom);
    console.log(window.screen.height - ele[0].getBoundingClientRect().bottom) - 80;
    var avail_height = (window.screen.height - ele[0].getBoundingClientRect().bottom);
    var countryName = null;
    var activityName = null;
    var activityType = null;
    table = $('#hblTable').DataTable({
        paging: true,
        scrollX: true,
        scroller: true,
        processing: true,
        serverSide: true,
        scrollY: avail_height < 400 ? avail_height - 120 : avail_height - 140,
        orderCellsTop: true,
        info: true,
        "ajax": {
            "url": GetHBLsUrl,
            "type": "POST",
            "data": function (d) {
                d.country = countryName;
                d.activity = activityName;
                d.search = searchValue;
                d.type = activityType;

            }
        },
        "columns": [
            {
                "data": null,

            },
            { "data": "id", "name": "id", "label": "Id", "visible": false },
            { "data": "hblNumber", "name": "hblNumber", "label": "HBL#", "autoWidth": true },
            { "data": "bookingNo", "name": "bookingNo", "label": "Booking#", "autoWidth": true },
            { "data": "pod", "name": "pod", "label": "POD", "autoWidth": true },
            //{ "data": "customerName", "name": "customerName", "label": "Customer Name", "autoWidth": true },
            { "data": "activity", "name": "activity", "label": "Activity", "autoWidth": true, contenteditable: true },
            { "data": "status", "name": "status", "label": "Status", "autoWidth": true, contenteditable: true },
            { "data": "comment", "name": "comment", "label": "Comment", contenteditable: true },
            {
                "data": null, "autoWidth": true,
                "render": function (data, type, row, meta) {

                    if (data.user === data.currentUser || data.user === null) {
                        return '<button type="button" class=" edit-btn btn btn-default mr-1"><i class="fa fa-edit" style="color: green;"></i></button>'
                    }
                    else {
                        return '';
                    }

                }
            },

        ],

        "columnDefs": [

            {
                className: 'dt-control',
                orderable: false,
                data: null,
                defaultContent: '',
                targets: 0
            },
            { width: "5%", targets: 1, visible: false },
        ]
    });
}

// Add search inputs for each column
$('#search-row input').on('keyup change', function () {
    table.settings()[0].oFeatures.bServerSide = false; // set serverSide back to false
    var i = $(this).parent().index() + 1;
    var searchstring = this.value.toString().trim();
    table.column(i).search(searchstring).draw();
    table.settings()[0].oFeatures.bServerSide = true; // set serverSide back to true
});

$('#hblTable').on('click', '.cancel-btn', function () {
    const row = $(this).closest('tr');
    const activitycell = table.cell(row, 6);
    const statuscell = table.cell(row, 7);
    const commentcell = table.cell(row, 8);
    const status = statuscell.node().querySelector('select').value;
    const comment = commentcell.node().querySelector('input').value;
    const activity = activitycell.node().querySelector('select').value;
    const statusoption = statuscell.node().querySelector('select option:checked');
    const rowData = table.row(row).data();
    const startDate = $('#dateTime').val();

    const HBLActivityLogViewModel = {
        HBLId: rowData.id,
        ActivityId: activity,
        StatusId: status,
        Comment: comment,
        StartDate: startDate,
        UserId: rowData.user
    };

    console.log("Data:" + HBLActivityLogViewModel);

    $.ajax({
        type: "post",
        url: AddHBLActivitiesUrl,
        data: {
            model: HBLActivityLogViewModel,
            button: "Cancel",
            statusValue,
            startDateValue,
            endDateValue,
            hblComments
        },
        datatype: "json",
        cache: false,
        success: function (data) {
            if (data == "Error while processing the request" || data == "Please select activitiy" || data == "Please select status") {
                setTimeout(function () {
                    //location.reload();
                }, 2000);
            } else {
                activitycell.node().contenteditable = false;
                statuscell.node().contenteditable = false;
                commentcell.node().contenteditable = false;
                setTimeout(function () {
                    //location.reload();
                    $('#hblTable').DataTable().ajax.reload();
                }, 2000);
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error!');
        }
    });

    activitycell.node().contenteditable = false;
    statuscell.node().contenteditable = false;
    commentcell.node().contenteditable = false;
    $(this).removeClass('btn-default save-button').addClass('btn-default edit-btn').html('<i class="fa fa-edit" style="color: green;"></i>');
    $('.edit-btn').not(this).prop('disabled', false);
});

$('#hblTable').on('click', '.edit-btn', function () {
    setFormattedDateTime();

    const row = $(this).closest('tr');
    const activitycell = table.cell(row, 6);
    const statuscell = table.cell(row, 7);
    const commentcell = table.cell(row, 8);
    const statusdata = statuscell.data();
    const commentdata = commentcell.data();
    const activitydata = activitycell.data();
    var activityList = activityIdDataList[0];
    var activityId = activityList.id;
    var activity = activityList.nameOfActivity;
    let selectedActivity = null;

    for (let i = 0; i < activityList.length; i++) {
        if (activityList[i].nameOfActivity === activitydata) {
            selectedActivity = activityList[i].id;
            break;
        }
    }

    const rowData = table.row(row).data();
    endDateValue = rowData.endDate;
    statusValue = statusdata;
    startDateValue = $('#dateTime').val();
    hblComments = rowData.comment;
    const startDate = $('#dateTime').val();
    const HBLActivityLogViewModel = {
        HBLId: rowData.id,
        ActivityId: selectedActivity,
        StatusId: statusdata,
        Comment: commentdata,
        StartDate: startDate,
        UserId: rowData.user
    };

    console.log("Data:" + HBLActivityLogViewModel);

    $.ajax({
        type: "post",
        url: AddHBLActivitiesUrl,
        data: {
            model: HBLActivityLogViewModel,
            button: "Edit",
            statusValue: statusValue,
            startDateValue: startDateValue,
            endDateValue: endDateValue,
            hblComments: hblComments
        },
        datatype: "json",
        cache: false,
        success: function (data) {
            if (data === "Error while processing the request" || data === "Please select activitiy" || data === "Please select status") {
                toastr.error('Error while processing the request.');
                setTimeout(function () {
                    //location.reload();
                    $('#hblTable').DataTable().ajax.reload();
                }, 5000);
            } else {
                setTimeout(function () {
                    //location.reload();
                }, 5000);
                const activityInput = $(`<select class="form-control" id="activity" data-row"${row.ActivityId}">
                      <option value="">--select--</option>
                      @foreach(var activityitem in activity){
                        <option value="@activityitem.Id">@activityitem.NameOfActivity</option>
                      }
                    </select>`).val(activitydata);

                const statusInput = $(`<select class="form-control" id="status" data-row"${row.StatusId}">
                      <option value="">--select--</option>
                      @foreach(var item in status){
                        <option value="@item.Id">@item.Status</option>
                      }
                    </select>`).val(statusdata);

                const commentInput = $('<input type="text" class="form-control">').val(commentdata);

                activitycell.node().innerHTML = '';
                statuscell.node().innerHTML = '';
                commentcell.node().innerHTML = '';

                if (activityInput.length) {
                    activityInput.appendTo(activitycell.node());
                }
                if (statusInput.length) {
                    statusInput.appendTo(statuscell.node());
                }
                if (commentInput.length) {
                    commentInput.appendTo(commentcell.node());
                }
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
            $('#hblTable').DataTable().ajax.reload();
            //location.reload();
        }
    });

    $(this).removeClass('btn-default edit-btn').addClass('btn-default save-button mr-1').html('<i class="fa fa-save" style="color: green;"></i>');
    $('.edit-btn').not(this).prop('disabled', true);
    const cancelButton = $('<button class="btn btn-default cancel-btn"><i class="fa fa-times" style="color: red;"></i></button>');
    cancelButton.insertAfter($(this));
});


$('#hblTable').on('click', '.save-button', function () {
    const row = $(this).closest('tr');
    const activitycell = table.cell(row, 6);
    const statuscell = table.cell(row, 7);
    const commentcell = table.cell(row, 8);
    const status = statuscell.node().querySelector('select').value;
    const comment = commentcell.node().querySelector('input').value;
    const activity = activitycell.node().querySelector('select').value;
    const statusoption = statuscell.node().querySelector('select option:checked');
    const statusName = statusoption.textContent;
    const rowData = table.row(row).data();

    if (activity === "") {
        toastr.warning('Please select activity.');
        return;
    }

    if (statusName === "") {
        toastr.warning('Please select status.');
        return;
    }

    if (statusName !== "Completed" && (comment === "" || comment === null || comment.length < 10)) {
        toastr.warning('Please enter a comment of at least 10 characters.');
        return;
    }

    const startDate = $('#dateTime').val();
    const HBLActivityLogViewModel = {
        HBLId: rowData.id,
        ActivityId: activity,
        StatusId: status,
        Comment: comment,
        StartDate: startDate,
        UserId: rowData.user
    };

    console.log("Data:" + HBLActivityLogViewModel);

    $.ajax({
        type: "post",
        url: AddHBLActivitiesUrl,
        data: {
            model: HBLActivityLogViewModel,
            button: "Save",
            statusValue,
            startDateValue,
            endDateValue,
            hblComments
        },
        dataType: "json",
        cache: false,
        success: function (data) {
            if (data === "Error while processing the request" || data === "Please select activity" || data === "Please select status") {
                toastr.error('Error while processing the request.');
                setTimeout(function () {
                    // location.reload();
                }, 5000);
            } else {
                toastr.success('HBL saved.');
                setTimeout(function () {
                    // location.reload();
                    $('#hblTable').DataTable().ajax.reload();
                }, 5000);
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error!');
            // location.reload();
        }
    });

    activitycell.node().contenteditable = false;
    statuscell.node().contenteditable = false;
    commentcell.node().contenteditable = false;
    $(this).removeClass('btn-default save-button').addClass('btn-default edit-btn').html('<i class="fa fa-edit" style="color: green;"></i>');
    $('.edit-btn').not(this).prop('disabled', false);
});

$('#hblTable tbody').on('click', 'td.dt-control', function () {

    var tr = $(this).closest('tr');
    var row = table.row(tr);

    if (row.child.isShown()) {
        row.child.hide();
        tr.removeClass('shown');
    } else {
        table.rows().every(function () {
            if (this.child.isShown()) {
                this.child.hide();
                $(this.node()).removeClass('shown');
            }
        });

        formatHBL(row.child, row.data());
        tr.addClass('shown');
    }
});

function formatHBL(callback, d) {
    console.log(d);
    // `d` is the original data object for the row

    $.ajax({
        url: GetHBLActivityUrl,
        type: "GET",
        data: {
            Id: d.id
        },
        success: function (response) {

            // Loop through the hbl array in the response
            if (response.hbl.length > 0) {
                var tableHTML = '<div class="table-responsive"><table class="table table-bordered" width="100%" cellpadding="2" cellspacing="0" border="0" style="padding-left:50px;margin-bottom: 0px;">';
                tableHTML = tableHTML + '<thead class="thead-dark"><tr><th hidden></th><th>Activity Name</th><th>Status</th><th>Processed Date</th><th>UserName</th><th>Comment</th></tr></thead><tbody>';
                for (var i = 0; i < response.hbl.length; i++) {
                    // Get the current hbl object
                    var HBL = response.hbl[i];
                    var date = new Date(HBL.processedDate);
                    // Add a new row to the table for the hbl object
                    tableHTML += "<tr>";
                    tableHTML += "<td hidden>" + HBL.id + "</td>";
                    tableHTML += "<td>" + HBL.activityName + "</td>";
                    tableHTML += "<td>" + HBL.status + "</td>";
                    tableHTML += "<td>" + formatDate(date, "dd/MM/yyyy HH:mm:ss") + "</td>";
                    tableHTML += "<td>" + HBL.user + "</td>";
                    tableHTML += "<td>" + HBL.comment + "</td>";
                    tableHTML += "</tr>";
                }
                tableHTML = tableHTML + '</tbody></table></div>';
            }
            else {
                var tableHTML = '<div class="table-responsive"><table class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;margin-bottom: 0px;"><tbody>';
                tableHTML += '<tr align="Center" style="padding:2px"><td colspan="6">No Data to Show</td></tr>';
                tableHTML = tableHTML + '</tbody></table></div>';
            }



            callback(tableHTML).show();
        }
    })
}

const searchBoxes = document.querySelectorAll('.search-box');
const tableRows = document.querySelectorAll('table tbody tr');

searchBoxes.forEach((searchBox, columnIndex) => {
    searchBox.addEventListener('input', function () {
        const searchText = searchBox.value.toLowerCase();
        tableRows.forEach(row => {
            const cells = row.querySelectorAll('td');
            let matches = false;
            const cell = cells[columnIndex];
            if (cell.textContent.toLowerCase().includes(searchText)) {
                matches = true;
            }
            row.style.display = matches ? '' : 'none';
        });
    });
});


function showCreateHBLPopUp() {
    $('.select2').select2();
    setFormattedDateTime();
    $.ajax({
        url: CreateHBLUrl,
        type: 'GET',
        success: function (data) {
            $('#modal-content').html(data);
            $('#modal-content').modal();
            $('.select2').select2();
            $.getScript('/js/Validation.js', function () {
                // Bind the blur event handlers
                $('#HBLFileNo').on('blur', validateHBLFileNumber);
                $('#Container').on('blur', validateContainer);
                $('#Comment').on('blur', validateComment);
                //$('#HBLStatus').on('blur', validateStatus);
                $('#HBLNo').on('blur', validateHBL);
                var fileNo = $('#HBLFileNo').val();
                if (fileNo != null || fileNo != undefined || fileNo != '') {
                    fileChange();

                }
                $('#AddContainerButton').on('click', function (event) {
                    addContainer(event);
                });
                $('#SaveContainerButton').on('click', function () {
                    saveContainer();
                });
            });

        },
        error: function () {
            alert("There is some problem in the service!")
        }
    });
}


function addContainer(event) {
    event.preventDefault();
    event.stopPropagation();

    $('#AddContainerButton').hide();
    $('#AddContainerInputSection').show();
}
function saveContainer() {
    var containerInputValue = $('#ContainerInput').val();
    if (containerInputValue) {
        var containerSelect = $('#Container');
        var newOption = $('<option>').val(containerInputValue).text(containerInputValue);
        containerSelect.append(newOption);
        containerSelect.val(containerInputValue).trigger('change');
        $('#ContainerInput').val('');
        $('#AddContainerInputSection').hide();
        $('#AddContainerButton').show();
    }

}

function saveHBL() {
    const HBLActivitiesArray = [];
    const HBLActivitiesModel = {
        ActivityId: $('#HBLActivity').val(),
        StatusId: $('#HBLStatus').val(),
        Comment: $('#Comment').val()
    };

    HBLActivitiesArray.push(HBLActivitiesModel);

    const HBLFileNo = $('#HBLFileNo').val();
    const HBLNo = $('#HBLNo').val();
    const HBLActivitySelectedValue = $('#HBLActivity option:selected').val();
    const HBLStatusSelectedValue = $('#HBLStatus option:selected').val();

    if (!HBLFileNo) {
        toastr.warning('Please enter file number');
        return;
    }
    if (!HBLNo) {
        toastr.warning('Please enter HBL number');
        return;
    }
    if (HBLActivitySelectedValue === "none" || HBLActivitySelectedValue === "") {
        toastr.warning('Please select an activity');
        return;
    }
    if (HBLStatusSelectedValue === "none" || HBLStatusSelectedValue === "") {
        toastr.warning('Please select a status');
        return;
    }

    const HBLUserViewModel = {
        CountryId: $('#HBLcountryLists').val(),
        FileNo: HBLFileNo,
        Container: $('#Container').val(),
        BookingNo: $('#BookingNo').val(),
        HBL_No: HBLNo,
        //CustomerName: $('#Customer').val(),
        StartDateTime: $('#dateTime').val(),
        HBLActivities: HBLActivitiesArray,
    };

    console.log(HBLActivitiesArray);
    $.ajax({
        type: "post",
        url: AddNewHBLActivityUrl,
        data: HBLUserViewModel,
        datatype: "json",
        cache: false,
        success: function (data) {
            if (data == "Error while processing the request") {
                toastr.error('Error while processing the request.');
            } else if (data == "Duplicate") {
                toastr.warning('Activity with the same name already exists');
            } else if (data == "File does not exist first insert file") {
                toastr.warning('File does not exist, please insert the file first.');
            } else if (data == "HBL no is already added") {
                toastr.warning('HBL number is already added.');
            } else {
                toastr.success('HBL Inserted Successfully!');
                setTimeout(function () {
                    $('#modal-content').modal('hide');
                    $("#modal-content").hide();
                    $('#hblTable').DataTable().ajax.reload();
                }, 5000);
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error!');
        }
    });
}


function setFormattedDateTime() {
    let dateTime = new Date(); // create a new Date object with the current date and time
    let utcDate = dateTime.getUTCDate();
    let utcMonth = dateTime.getUTCMonth() + 1; // getMonth() returns 0-11, so add 1 to get the actual month
    let utcYear = dateTime.getUTCFullYear();
    let utcHours = dateTime.getUTCHours();
    let utcMinutes = dateTime.getUTCMinutes();
    let utcSeconds = dateTime.getUTCSeconds();
    let formattedDateTime = new Date(Date.UTC(utcYear, utcMonth - 1, utcDate, utcHours, utcMinutes, utcSeconds)).toLocaleString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hour12: true
    }); // format the date and time string in the desired format
    $('#dateTime').val(formattedDateTime);
}


function fileChange() {
    const fileNo = $('#HBLFileNo').val();
    console.log("fileNo", fileNo);

    $.ajax({
        type: "GET",
        url: GetContainerUrl,
        data: { fileNo },
        datatype: "json",
        cache: false,
        success: function (data) {
            const successMessage = {
                Error: 'Error while processing the request.',
                Duplicate: 'Activity with same name already exists.',
                'File does not exist first insert file': 'File does not exist, please insert file first.',
                'HBL no is already added': 'HBL no is already added.'
            };

            if (data.success === "Error while processing the request" || data.success === "Duplicate" || data.success === "File does not exist first insert file" || data.success === "HBL no is already added") {
                toastr.warning(successMessage[data.success]);
            } else {
                const containerSelect = $('#Container');
                containerSelect.empty();
                containerSelect.append($('<option>').val('').text('-- Select Container --'));

                $.each(data.containerList, function (index, container) {
                    containerSelect.append($('<option>').val(container.id).text(container.containerNo));
                });

                // Refresh the select2 control
                containerSelect.trigger('change');
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error!');
        }
    });
}
