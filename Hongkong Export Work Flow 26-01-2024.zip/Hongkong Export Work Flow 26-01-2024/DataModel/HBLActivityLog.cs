﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{
    public partial class HBLActivityLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string HBLId { get; set; }

        public string? ActivityId { get; set; }

        public string? StatusId { get; set; }

        public string? Comment { get; set; }

        public string? UserId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        [ForeignKey("ActivityId")]
        public virtual ActivityMaster Activity { get; set; } = null!;

        [ForeignKey("HBLId")]
        public virtual HBLMaster Hbl { get; set; } = null!;

        [ForeignKey("StatusId")]
        public virtual StatusMaster Status { get; set; } = null!;

        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; } = null!;
        public virtual ICollection<HBLActivitylogHistory> HBLActivitylogHistory { get; } = new List<HBLActivitylogHistory>();
    }
}