﻿using System;
namespace APACExportTrackX.ViewModels
{
    public class FileDashModel
    {
        public string Id { get; set; }
        public string FileId { get; set; }
        public string? FileLogId { get; set; }
        public string FileNumber { get; set; }
        public string? FileType { get; set; }
        public string? ActivityType { get; set; }
        public string? POD { get; set; }
        public int? LBL { get; set; }
        public int? TBL { get; set; }
        public int? TotalHBL { get; set; }
        public string? ShippingLine { get; set; }
        public DateTime? SICutOff { get; set; }
        public string? FileContact { get; set; }
        public string? FileActivityLogId { get; set; }
        public string? ContainerNo { get; set; }
        public string? ContainerId { get; set; }
        public string? MBL { get; set; }
        public string? Vessel { get; set; }
        public string? Voyage { get; set; }
        public string? FileRemark { get; set; }
        public string? ShippingAgent { get; set; }
        public string? Coload { get; set; }
        public DateTime? ETD { get; set; }
        public DateTime? ETA { get; set; }
        public DateTime? ETAPOD { get; set; }
        public DateTime? ATD { get; set; }
        public DateTime? EnterDate { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
        public string? ActivityId { get; set; }
        public string? StatusId { get; set; }
        public DateTime? StatusCompleted { get; set; }
        public string? TallySheetId { get; set; }
        public DateTime? TallySheetCompleted { get; set; }
        public string? MblReviewId { get; set; }
        public DateTime? MblReviewCompleted { get; set; }
        public string? TblProcessingId { get; set; }
        public string? BLRequestId { get; set; }
        public DateTime? TblProcessingCompleted { get; set; }
        public DateTime? BLRequestCompleted { get; set; }
        public string? Comment { get; set; }
        public string? Roe { get; set; }
        public string? TallySheetComment { get; set; }
        public string? MblReviewComment { get; set; }
        public string? TblProcessingComment { get; set; }
        public string? BLRequestComment { get; set; }
        public string? UserId { get; set; }
        public string? CurrentUser { get; set; }
        public string? Role { get; set; }
        public string? CarrierRequest { get; set; }
        public string? BLRequest { get; set; }
        public DateTime? CarrierRequestCompleted { get; set; }
        public string? Telex { get; set; }
        public DateTime? TelexCompleted { get; set; }
        public string? OBDDN { get; set; }
        public DateTime? OBDDNCompleted { get; set; }
        public string? SIToCarrier { get; set; }
        public DateTime? SIToCarrierCompleted { get; set; }
        public string? ShippingConfirmation { get; set; }
        public string? MBLReview { get; set; }
        public DateTime? MBLReviewsCompleted { get; set; }
        public string? Invoice { get; set; }
        public DateTime? InvoiceCompleted { get; set; }
        public string? FinalBL { get; set; }
        public DateTime? FinalBLCompleted { get; set; }
        public string? PreAlert { get; set; }
        public DateTime? PreAlertCompleted { get; set; }
        public string? Permit { get; set; }
        public DateTime? PermitCompleted { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}

