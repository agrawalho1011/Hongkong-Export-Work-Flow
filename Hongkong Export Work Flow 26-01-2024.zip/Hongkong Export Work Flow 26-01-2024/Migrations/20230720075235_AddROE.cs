﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APACExportTrackX.Migrations
{
    public partial class AddROE : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Roe",
                table: "FileActivityLog",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Roe",
                table: "FileActivityLog");
        }
    }
}
