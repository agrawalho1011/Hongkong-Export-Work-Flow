﻿using APACExportTrackX.DataModel;
using APACExportTrackX.LDAP;
using APACExportTrackX.ViewModels;
using HongkongExportTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace APACExportTrackX.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> userManger;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly RoleManager<IdentityRole> roleManager;
        public ApplicationDBContext _ctx;
        private readonly LdapUserManager<ApplicationUser> ldapUserManager;


        public AccountController(UserManager<ApplicationUser> userManger, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole> roleManager, ApplicationDBContext ctx)
        {
            this.userManger = userManger;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            _ctx = ctx;
            this.ldapUserManager = ldapUserManager;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        [Authorize(Roles = "Supervisor,Manager")]
        [HttpGet]
        public IActionResult Index(string userId)
        {

            var result = _ctx.Users.Select(x => new RegisterViewModel
            {
                FirstName = x.FirstName,
                LastName = x.LastName,
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                EmpId = x.EmpId,
                IsActive = x.IsActive,
                IsDelete = x.IsDelete,
                Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                IsLDAP = x.IsLDAP,
                IsReset = x.IsReset,
            }).Where(x => x.IsDelete == false).ToList();

            ViewData["User"] = _ctx.Users.ToList();
            ViewData["Roles"] = roleManager.Roles.ToList(); 
            
            if (userId != null)
            {
                result = _ctx.Users.Where(x => x.Id == userId).Select(x => new RegisterViewModel
                {
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    UserName = x.UserName,
                    CitrixId = x.CitrixId,
                    EmpId = x.EmpId,
                    IsActive = x.IsActive,
                    IsDelete = x.IsDelete,
                    Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                    IsLDAP = x.IsLDAP,
                    IsReset = x.IsReset,
                }).Where(x => x.IsDelete == false).ToList();
                return Json(result);
            }
            return View(result);
        }

        //[HttpPost]
        //public async Task<IActionResult> Login(LoginViewModel model)
        //{

        //    if (ModelState.IsValid)
        //    {
        //        var result = await signInManager.PasswordSignInAsync(model.CitrixId, model.Password, false, false);
        //        var users = _ctx.Users.Where(x => x.IsActive == true && x.IsDelete == false);
        //        if (result.Succeeded)
        //        {
        //            if (users.Count() == 0)
        //            {
        //                ModelState.AddModelError(string.Empty, "User is inactive.");
        //                return View(model);
        //            }
        //            var user = await userManger.FindByNameAsync(model.CitrixId);
        //            var roles = await userManger.GetRolesAsync(user);
        //            if (roles.Count != 0)
        //            {
        //                if (roles[0].ToString() == "Supervisor" || roles[0].ToString() == "Manager")
        //                {
        //                    return RedirectToAction("Index", "Dashboard");
        //                }
        //                else if (roles[0].ToString() == "User")
        //                {
        //                    return RedirectToAction("UserThread", "User");
        //                }
        //                else
        //                {
        //                    return NotFound();
        //                }
        //            }
        //        }
        //        //ModelState.AddModelError("", "Invalid Login Attempt");
        //        return View(model);
        //    }
        //    else
        //    {
        //        ModelState.AddModelError(string.Empty, "Invalid login attempt.");
        //        return View(model);
        //    }


        //}


        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                ApplicationUser users = _ctx.Users.Where(x => x.CitrixId == model.CitrixId).FirstOrDefault();
                if (users == null)
                {
                    ModelState.AddModelError(string.Empty, "Invalid user id.");
                    return View(model);
                }
                if (users.IsLDAP == true || users.IsLDAP == null)
                {
                    var result = await ldapUserManager.CheckPasswordAsync(users, model.Password);
                    if (result)
                    {
                        await signInManager.SignInAsync(users, isPersistent: false);
                        var user = await ldapUserManager.FindByNameAsync(model.CitrixId);
                        var roles = await ldapUserManager.GetRolesAsync(user);

                        if (roles.Count != 0)
                        {
                            if (roles.Count() == 1)
                            {
                                if (roles[0].ToString() == "Supervisor" || roles[0].ToString() == "Manager")
                                {
                                    return RedirectToAction("Index", "Dashboard");
                                }
                                else if (roles[0].ToString() == "User")
                                {
                                    return RedirectToAction("UserThread", "User");
                                }
                            }
                            else
                                return RedirectToAction("SelectRole", "User");
                        }
                        else
                            ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                    }
                    ModelState.AddModelError("", "Invalid Login Attempt");
                    return View(model);

                }
                else
                {
                    if (users.IsReset == false)
                    {
                        var result = await signInManager.PasswordSignInAsync(users, model.Password, false, false);
                        var userList = _ctx.Users.Where(x => x.IsActive == true && x.IsDelete == false);
                        if (result.Succeeded)
                        {
                            if (userList.Count() == 0)
                            {
                                ModelState.AddModelError(string.Empty, "User is inactive.");
                                return View(model);
                            }
                            var user = await userManger.FindByNameAsync(model.CitrixId);
                            var roles = await userManger.GetRolesAsync(user);
                            if (roles.Count != 0)
                            {
                                if (roles[0].ToString() == "Supervisor" || roles[0].ToString() == "Manager")
                                {
                                    return RedirectToAction("Index", "Dashboard");
                                }
                                else if (roles[0].ToString() == "User")
                                {
                                    return RedirectToAction("UserThread", "User");
                                }
                                else
                                {
                                    return NotFound();
                                }
                            }
                        }
                    }
                    else
                    {
                        return RedirectToAction("ChangePassword", "Account", new { Username = users.UserName });
                    }
                }

                //ModelState.AddModelError("", "Invalid Login Attempt");
                return View(model);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }


        }


        [HttpGet]
        public IActionResult ChangePassword(string Username)
        {
            if (Username == null)
            {
                if (User.Identity.IsAuthenticated)
                {
                    Username = userManger.GetUserName(User).ToString();
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            ViewData["User"] = userManger.Users.FirstOrDefault(x => x.UserName == Username);

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            //var user = await userManger.GetUserAsync(User);

            //if (user == null)
            //{
            //    // Handle the case where the user is not found
            //    return NotFound();
            //}

            if (ModelState.IsValid)
            {
                ApplicationUser user = new ApplicationUser();

                if (User.Identity.IsAuthenticated)
                {
                    user = await userManger.GetUserAsync(User);
                }
                else
                {
                    user = _ctx.Users.FirstOrDefault(x => x.UserName == model.Username);
                    user.IsReset = false;
                    _ctx.Update(user);
                }

                var result = await userManger.ChangePasswordAsync(user, model.CurrentPassword.Trim(), model.NewPassword.Trim());

                if (result.Succeeded)
                {
                    return Json("success");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            ViewData["roles"] = roleManager.Roles.ToList();
            return View("ChangePassword", model);
        }




        private bool IsPasswordValid(string password)
        {
            // Add your password validation logic here
            // For example, using a regular expression
            const string passwordRegex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$";
            return Regex.IsMatch(password, passwordRegex);
        }


        public IActionResult ResetPassword()
        {
            // Retrieve users based on role (in this case, "user")
            ViewData["User"] = _ctx.Users.ToList();
            return View();
        }

        // POST: /User/GeneratePassword
        [HttpPost]
        public IActionResult GeneratePassword(string userName)
        {
            // Generate random password
            string newPassword = GenerateRandomPassword();
            newPassword = newPassword.Trim();

            // Update user's password
            var user = userManger.FindByNameAsync(userName).Result;
            var token = userManger.GeneratePasswordResetTokenAsync(user).Result;
            var result = userManger.ResetPasswordAsync(user, token, newPassword).Result;


            if (result.Succeeded)
            {
                // Save the new password to the database or perform any other necessary actions
                // You can add code here to save the newPassword to the database
                // For simplicity, I'll assume you have a method like SavePasswordToDatabase(userId, newPassword)

                // SavePasswordToDatabase(userId, newPassword);

                // Return the new password to the view
                return Json(new { newPassword });
            }
            else
            {
                // Handle password reset failure
                return Json(new { error = "Password reset failed." });
            }
        }


        // While creating random password check validation for must contain at least 1 digit one uppercase and one special character
        private string GenerateRandomPassword()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~!@#$%^&*()_+/`';.,/][}{:?><";
            var random = new Random();

            // Generate until the password meets the requirements
            string newPassword;
            do
            {
                newPassword = new string(Enumerable.Repeat(chars, 12)
                  .Select(s => s[random.Next(s.Length)]).ToArray());
            } while (!PasswordMeetsRequirements(newPassword));

            return newPassword;
        }

        private bool PasswordMeetsRequirements(string password)
        {
            // Check if the password contains at least one digit, one uppercase letter, and one special character
            return password.Any(char.IsDigit) && password.Any(char.IsUpper) && password.Any(char.IsLower) && password.Any(IsSpecialCharacter);
        }

        private bool IsSpecialCharacter(char c)
        {
            const string specialCharacters = "~!@#$%^&*()_+/`';.,/][}{:?<>";

            // Check if the character is a special character
            return specialCharacters.Contains(c);
        }



        [Authorize(Roles = "Supervisor,Manager")]
        [HttpGet]
        public IActionResult Register()
        {
            ViewData["Roles"] = roleManager.Roles.ToList();

            //ViewData["Roles"] = _ctx.Roles.Select(x => new RoleManager
            //{
            //	Id = x.Id,
            //	Name = x.Name

            //}).ToList();

            return View(new RegisterViewModel());
        }

        [Authorize(Roles = "Supervisor,Manager")]
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {

            Console.Write("--------------------------------------------------------------");
            Console.Write(model.Role);
            if (ModelState.IsValid)
            {
                var userList = _ctx.Users.Where(x => x.CitrixId.ToLower() == model.CitrixId.ToLower() || x.UserName.ToLower() == model.UserName.ToLower() || x.EmpId == model.EmpId).ToList();

                if (userList == null || userList.Count == 0)
                {
                    var user = new ApplicationUser
                    {
                        CitrixId = model.CitrixId,
                        EmpId = model.EmpId,
                        UserName = model.UserName,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        IsActive = true,
                        NormalizedUserName = model.UserName.ToUpper()
                    };


                    var roleId = _ctx.Roles.Where(x => x.Name == model.Role).Select(x => x.Id).FirstOrDefault();

                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = roleId,
                        UserId = user.Id,
                    });

                    var result = await userManger.CreateAsync(user);
                    _ctx.SaveChanges();
                    //if (result.Succeeded)
                    //{
                    //    //await userManger.AddToRoleAsync(user, model.Role);

                    //    return RedirectToAction("Index", "Account");
                    //}
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                        return Json("error");
                    }
                }
                else
                {
                    return Json("UserName, CitrixId or EmpId already Exist.");
                }
            }

            return Json("success");
        }

        [Authorize(Roles = "Supervisor,Manager")]
        [HttpPost]
        public async Task<JsonResult> UpdateRole(UpdateRoleModel data)
        {

            var user = _ctx.Users.Where(x => x.CitrixId == data.CitrixId && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            var userrole = _ctx.UserRoles.Where(x => x.UserId == user.Id).FirstOrDefault();

            if (user != null)
            {
                try
                {
                    _ctx.Remove(userrole);
                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = data.RoleId,
                        UserId = user.Id,
                    });

                    _ctx.SaveChanges();
                }
                catch (Exception ex) { }
                return Json("success");
            }
            else
            {
                return Json("failed");
            }

        }

        [Authorize(Roles = "Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditUser(string Uname)
        {
            ViewData["EditUser"] = _ctx.Users.Where(x => x.UserName.ToLower() == Uname.Trim().ToLower() && x.IsActive == true && x.IsDelete == false).FirstOrDefault();

            return PartialView();
        }

        [HttpPost]
        public async Task<JsonResult> EditUser(ApplicationUser model)
        {
            var uname = _ctx.Users.Where(x => x.Id == model.Id && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            if (uname != null)
            {
                uname.FirstName = model.FirstName.Trim();
                uname.LastName = model.LastName.Trim();
                uname.UserName = model.UserName.Trim();
                uname.CitrixId = model.CitrixId.Trim();
                uname.EmpId = model.EmpId;
                uname.NormalizedUserName = model.CitrixId.ToUpper().Trim();
                _ctx.Users.Update(uname);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }

        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }
    }
}