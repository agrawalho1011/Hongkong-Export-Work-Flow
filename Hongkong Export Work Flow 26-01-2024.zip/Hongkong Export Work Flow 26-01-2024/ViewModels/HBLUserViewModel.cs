﻿namespace APACExportTrackX.ViewModels
{
    public class HBLUserViewModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? CountryName { get; set; }
        public string FileNo { get; set; }
        public string? Container { get; set; }
        //public string BookingNo { get; set; }
        public string? HBL_No { get; set; }
        //public string? CustomerName { get; set; }
        public string? StartDateTime { get; set; }


        public List<HBLActivityLogs>? HBLActivities { get; set; }
        public List<string> HBLNumbers { get; set; }
        public List<string> BookingNumbers { get; set; }
        //public List<string> CustomerNames { get; set; }
    }
    public class HBLActivityLogs
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string ActivityId { get; set; }
        public string StatusId { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; } = null!;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
    public class HBLQueryActivity
    {
        public string Id { get; set; }
        public string CountryId { get; set; }
        public string? CountryName { get; set; }
        public string FileNo { get; set; }
        public string? Container { get; set; }
        public string BookingNo { get; set; }
        public string HBL_No { get; set; }
        public string CustomerName { get; set; }        
        public string ActivityId { get; set; }
        public string StatusId { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; } = null;
        public DateTime? ProcessDate { get; set; }
    }
    public class FileQueryActivity
    {
        public string Id { get; set; }
        public string Filenumber { get; set; }
        public string ActivityId { get; set; }
        public string StatusId { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; } = null;
        public DateTime? ProcessDate { get; set; }
    }
}