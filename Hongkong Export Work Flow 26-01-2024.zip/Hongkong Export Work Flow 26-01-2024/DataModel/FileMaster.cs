﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{

    public partial class FileMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString(); 
        public string FileNumber { get; set; }
        public string? FileType { get; set; }
        public string? POD { get; set; }
        public int? TotalBL { get; set; }
        public string? ShippingLine { get; set; }
        public string? FileContact { get; set; }
        public string? MBL { get; set; }
        public string? Vessel { get; set; }
        public string? Voyage { get; set; }
        public string? FileRemark { get; set; }
        public string? ShippingAgent { get; set; }
        public string? Coload { get; set; }
        public DateTime? ETD { get; set; }
        public DateTime? ETA { get; set; }
        public DateTime? ETAPOD { get; set; }
        public DateTime? ATD { get; set; }
        public DateTime? EnterDate { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool? IsDelete { get; set; } = false;

        [ForeignKey("POD")]
        public virtual CountryMaster CountryMaster { get; set; }
        public virtual ICollection<FileActivityLog> FileActivityLogs { get; } = new List<FileActivityLog>();
        public virtual ICollection<HBLMaster> HBLMasters { get; } = new List<HBLMaster>();
        public virtual ICollection<ContainerMaster> ContainerMaster { get; } = new List<ContainerMaster>();
    }
}