﻿namespace APACExportTrackX.ViewModels
{

    public class AdhocFileActivityModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string CountryId { get; set; }
        public string AdhocFileNumber { get; set; } = null!;
        public string AdhocContainer { get; set; } = null!;
        public DateTime? EnterDate { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

        public List<AdhocFileActivityLogItem> AdhocFileActivities { get; set; }
    }
    public class AdhocFileActivityLogItem
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string ActivityId { get; set; }

        public string StatusId { get; set; }

        public string? Comment { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
